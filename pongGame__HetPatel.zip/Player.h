#pragma once
class Player
{
	private:
		int score;
	public:
		Player(int);
		int getScore();
		void updateScore();
};

